<footer>
<div class="container">
    <div class="row">
      <div class="col-lg-12">
        <p>Copyright &copy; Advance Media 2015</p>
      </div>
    </div>
    </div>
  </footer>

</body>
</html>
