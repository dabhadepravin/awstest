
<div id="container">
	<div>
            	<h1>Register</h1>
                <div class="content">
                	
                	<?php
                		if(isset($error) && !empty($error)){
                	?>
                		<div class="errorholder">
                			<span class="error"><?php echo $error;?></span>
                		</div>

                	<?php 
               			 }
                	?>

                    <p>Thank you for registration!</p>
                    <p>Soon  you will recevie password email</p>
                    <div style="text-align:center">
                    	<a href="/selfdfp" class="blackbutton">Start Campaign</a>
                    </div>
                    
                </div><!-- content -->
            </div><!-- widgetbox -->
    
    <div class="one_third last">
    	
    </div><!--one_third last-->
    
    <br clear="all" />
    
</div><!--maincontent-->

<br />

