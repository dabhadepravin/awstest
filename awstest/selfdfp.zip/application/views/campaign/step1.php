
<div id="container">
 <div>
  	<h1>Step1</h1>
   		<div class="content">
	 		<div class="clear"></div>
            
            <div class="widgetbox-step1">
            <div class="step1">
            <div class="pageTitle" style="text-align:center">Get Started</div>
            <div class="clear"></div>
            <div style="text-align:center;width:200px;margin:0 auto">
            	<button id="btn_step1" class="button button_black" style="width:200px;height:40px;">Start a Campaign</button>
            </div>	
            </div>
            </div><!-- widgetbox2 -->
            
            <br />
     <div class="one_third last">
    	
    </div><!--one_third last-->
    
    <br clear="all" />
    
</div><!--maincontent-->
</div>
</div>
<br />

