
<div id="container">
	<div>
            	<h1>Select Brand Categories</h1>
                <div class="content">
                	
                	<div>
					<span class="sectiontitle_nobg">Categories</span>
					<ul class="categories">
						<li class=""><a href="step3?cat=1">Women Related products</a></li>
						<li class=""><a href="step3?cat=2">Blogs</a></li>
						<li class=""><a href="step3?cat=3">Sports</a></li>
						<li class=""><a href="step3?cat=4">Kids</a></li>
						<li class=""><a href="step3?cat=5">Others</a></li>
					</ul>
			</div>
                    
                </div><!-- content -->
            </div><!-- widgetbox -->
    
    <div class="one_third last">
    	
    </div><!--one_third last-->
    
    <br clear="all" />
    
</div><!--maincontent-->

<br />
