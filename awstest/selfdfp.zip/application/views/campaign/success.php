
<div id="container">
 <div>
 	<div style="margin:30px;">
 	<p> Thanks for Order . Your order no is <strong><?php echo $orderno ?></strong></p>
 	<p> Your order is under processing, you will get an email after successful completion of order</p>
 	<p> for further communications , please provide your order no </p>
 	<p> Start new Campaign <a href="<?php echo site_url()?>advertiser">Click here </a></p>
 </div>
</div>
</div>
<br />

